class AiohttpLikeDjangoError(Exception):
    pass


class AiohttpLikeDjangoWarning(RuntimeWarning):
    pass


class AppRegistryNotReady(Exception):
    pass
